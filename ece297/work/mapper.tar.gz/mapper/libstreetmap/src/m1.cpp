/* 
 * Copyright 2018 University of Toronto
 *
 * Permission is hereby granted, to use this software and associated 
 * documentation files (the "Software") in course work at the University 
 * of Toronto, or for personal use. Other uses are prohibited, in 
 * particular the distribution of the Software either publicly or to third 
 * parties.
 *
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#include "m1.h"
//#include "intersection.h"
#include "StreetsDatabaseAPI.h"
#include <vector>
#include <string>
#include <math.h> //add this library in order to use pow()


        
//I(Zhen) will create some global variables & templates here
//template<typename intersection>
std::vector<StreetSegmentInfo> streetSegmentChain; //contains all StreetSegmentInfo
std::vector<StreetSegmentIndex> streetSegmentIndexChain; //contains all StreetSegmentIndex
std::vector<StreetIndex> streetIndexChain; //contains all StreetIndex
std::vector<OSMID> intersectionChain; // contains all intersection IDs

//Sooyeon will create some global variables here

bool load_map(std::string map_path) {
    bool abcda = loadStreetsDatabaseBIN(map_path);
    bool load_successful = false; //Indicates whether the map has loaded 
                                  //successfully
    //
    //Load your map related data structures here
    //We are going to use vector structure here
    //unsigned NumOfInteersections = getNumberOfIntersections();
    
    
    for(IntersectionIndex i = 0; i < getNumberOfIntersections(); i++){//i: intersection index
        intersectionChain.push_back(getIntersectionOSMNodeID(i));//we make the outer data stucture by the intersection OSM ID
        for(unsigned int j = 0; j < getIntersectionStreetSegmentCount(i); j++){//j: number of street segment(Nss)
            streetSegmentChain.push_back(getStreetSegmentInfo(getIntersectionStreetSegment(i, j)));//we make the inner data stucture by street segment information(a "struct")
        }      
    }
    load_successful = true; //Make sure this is updated to reflect whether
                            //loading the map succeeded or failed   
    return load_successful;
}

void close_map() {
    //Clean-up your map related data structures here
    closeStreetDatabase(); //call the function to free the memory
}

//Returns street id(s) for the given street name
//If no street with this name exists, returns a 0-length vector.
std::vector<unsigned> find_street_ids_from_name(std::string street_name){
    std::vector<unsigned> stIds; //vector containing street IDs
    for (auto i = streetIndexChain.begin(); i != streetIndexChain.end(); i++) { //go through list of street indexes
        if (getStreetName(*i) == street_name) { //see if any of the index has correct associated street name
            stIds.push_back(*i); // if name matches, then store that index number
        }
    } return stIds;
}

//Returns the street segments for the given intersection 
std::vector<unsigned> find_intersection_street_segments(unsigned intersection_id){
    std::vector<unsigned> stSegsFromInterId;
    int numSegs = getIntersectionStreetSegmentCount(intersection_id); //number of street segments at the intersection
    for (auto i = 0; i < numSegs; i++) {
        stSegsFromInterId.push_back(getIntersectionStreetSegment(intersection_id, i)); //added the stsegment indexes
    }
}

//Returns the street names at the given intersection (includes duplicate street 
//names in returned vector)
std::vector<std::string> find_intersection_street_names(unsigned intersection_id){
    
}

//Returns true if you can get from intersection1 to intersection2 using a single 
//street segment (hint: check for 1-way streets too)
//corner case: an intersection is considered to be connected to itself
bool are_directly_connected(unsigned intersection_id1, unsigned intersection_id2){
    int interSegCount = getIntersectionStreetSegmentCount(intersection_id1); //retrieve number of segments associated with intersection_!
    std::vector<IntersectionIndex> inter2 = find_adjacent_intersections(intersection_id1);
    for (int i = 0; i < interSegCount; i++) { //go through all segments to see if they are attached to intersection_2
        if (intersection_id2 == inter2[i]) {
            return true;
        }
    } return false;
}
//Returns all intersections reachable by traveling down one street segment 
//from given intersection (hint: you can't travel the wrong way on a 1-way street)
//the returned vector should NOT contain duplicate intersections
std::vector<unsigned> find_adjacent_intersections(unsigned intersection_id){
    std::vector<IntersectionIndex> adjInter;
    int interSegCount = getIntersectionStreetSegmentCount(intersection_id); //retrieve number of segments associated with intersection
    for (int i = 0; i <interSegCount; i++) { //creates list size of number of street segments
        StreetSegmentIndex temp = getIntersectionStreetSegment(intersection_id, i); //take one segment at a time
        
        //take in intersection ID to and from, associated with this street segment
        IntersectionIndex fromID = getStreetSegmentInfo(temp).from;
        IntersectionIndex toID = getStreetSegmentInfo(temp).to;

        bool exist = false; //see if id already exist in list
        
        for (int j = 0; j < i; j++) { // goes through existing items in list to see if segment already exists
            
            if (adjInter[j] == fromID || adjInter[j] == toID) {
                exist = true;
            }
        }
        
        if (fromID == intersection_id && !exist) { //if toID is adjacent to intersection_id
                adjInter.push_back(toID);
        } else if (toID == intersection_id && !getStreetSegmentInfo(temp).oneWay && !exist) {
            //if fromID is adjacent to intersection_id 
            //and allowed to move in that direction
            adjInter.push_back(fromID);
        }
        
//        } else { //if adjacent intersection exist but not allowed to go in that direction
//            adjInter.push_back(-1);
//        }
    } return adjInter;
}

//Returns all street segments for the given street
std::vector<unsigned> find_street_street_segments(unsigned street_id){
    std::vector<unsigned> allStSeg;
    for(auto i = streetSegmentIndexChain.begin(); i != streetSegmentIndexChain.end(); i++) { //go through entire vector with all street segments
        if (getStreetSegmentInfo(*i).streetID == street_id) { //identify if the street segment is associated with this streetID
            allStSeg.push_back(*i);
        }
    } return allStSeg;
}

//Returns all intersections along the a given street
std::vector<unsigned> find_all_street_intersections(unsigned street_id){
    std::vector<unsigned> allStInter;
    std::vector<unsigned> stSegs = find_street_street_segments(street_id); //holds st seg IDs associated with this street ID
    auto size = stSegs.size(); // number of st segments associated with this street ID
    for (auto i = 0; i < size; i++) {
        IntersectionIndex fromID = getStreetSegmentInfo(stSegs[i]).from;
        IntersectionIndex toID = getStreetSegmentInfo(stSegs[i]).to;
        bool existTo = false;
        bool existFrom = false;
        
        for (auto j = 0; j < i; j++) { // goes through existing items in list to see if segment already exists
            if (allStInter[j] == fromID) {
                existFrom = true;
            } else if(allStInter[j] == toID) {
                existTo = true;
            }
        }
        if (!existFrom) { // if the to or from index didn't exist in the list, add it to the allStInter vector
            allStInter.push_back(fromID);
        } if (!existTo) {
            allStInter.push_back(toID);
        }
    } return allStInter;
}


//Return all intersection ids for two intersecting streets
//This function will typically return one intersection id.
//However street names are not guarenteed to be unique, so more than 1 intersection id
//may exist
std::vector<unsigned> find_intersection_ids_from_street_names(std::string street_name1, 
                                                              std::string street_name2){
/*basic idea: firstly, get intersectionIDs  the two given street have respectively 
              secondly, compare these intersectionIds to see if there exists two street have same intersectionId*/
               
    
    std::vector<StreetIndex> streetOne = find_street_ids_from_name(street_name1);   //all intersections all along street_name1
    std::vector<StreetIndex> streetTwo = find_street_ids_from_name(street_name2);   // all intersection all along street_name2
    
    std::vector<IntersectionIndex> interIds;
    
    //corner case: street_name1 may intersect with two street_name2
    
    for (std::vector<StreetIndex>::iterator streetItOne = streetOne.begin(); streetItOne!= streetOne.end(); ++streetItOne) {   //iterator through intersections of street_one
         std::vector<IntersectionIndex> streetOneInter = find_all_street_intersections(*streetItOne);  //get all intersections ids of street_one
         for (std::vector<StreetIndex>::iterator  streetItTwo= streetTwo.begin(); streetItTwo != streetOne.end(); ++streetItTwo){//iterator through intersections of street_two
           std::vector<IntersectionIndex> streetTwoInter = find_all_street_intersections(*streetItTwo);//get all intersections ids of street_two
           for (std::vector<IntersectionIndex>::iterator interItOne = streetOneInter.begin(); interItOne != (streetOneInter.end()); ++interItOne) { //compare the two sets of ids  
               for (std::vector<IntersectionIndex>::iterator interItTwo = streetTwoInter.begin(); interItTwo != (streetTwoInter.end()); ++interItTwo){
                   if (*interItTwo == *interItOne) //if the two street have same intersection id, put the id into "interIds", otherwise do nothing
                       interIds.push_back(*interItOne);                
               }               
           }           
       }  
    }
    return interIds;
          
}

//Returns the distance between two coordinates in meters
double find_distance_between_two_points(LatLon point1, LatLon point2){
 //lon and lat in LatLon are in degree, need to be convert to radius to compute distance  
//rad = degree * DEG_TO_RAD 
    double lat_avg = (point1.lat() + point2.lat())*DEG_TO_RAD/2;   //lat_avg = (lat1+lat2)*DEG_TO_RAD /2) in rad
   double x1 = ( point1.lon()*DEG_TO_RAD ) * cos(lat_avg); //x = lon * cos(lat_avg)
    double y1 = point1.lat()*DEG_TO_RAD ; // y = lat
    double x2 = ( point2.lon() * DEG_TO_RAD ) * cos(lat_avg); 
    double y2 = point2.lat()*DEG_TO_RAD ;
    double distance = 0;
    
    //d = R *sqrt((y2-y1)^2 + (x2-x1)^2 ))
    double temp = pow((y2-y1),2) + pow((x2-x1),2);
    distance =  EARTH_RADIUS_IN_METERS * sqrt(temp);
    
    return distance;   
    
}

//Returns the length of the given street segment in meters
double find_street_segment_length(unsigned street_segment_id){
    
    //basic information about this street segment
   StreetSegmentInfo  segment_info = getStreetSegmentInfo(street_segment_id); 

   unsigned totalCount = segment_info.curvePointCount;  
   
    // start and end point of the street segment
    LatLon point1 = getIntersectionPosition (segment_info.from);
    LatLon point2 = getIntersectionPosition (segment_info.to);
    double distance = 0;
    
   if (totalCount == 0) {
       // this street segment doesn't have curve point
       distance = find_distance_between_two_points(point1, point2); 
   }
   else {
       // the street have curve points 
       //basic idea: distance = start point to 1st curve point + 1st curve point to ith curve point + ith curve point to the end point     
         for (unsigned i = 0 ; i <= (totalCount-1) ; i++){  
             LatLon curvePoint = getStreetSegmentCurvePoint (street_segment_id,i); //position of ith curve point
             if (i == 0) {
                 //start point to 1st curve point
               distance = distance + find_distance_between_two_points(point1, curvePoint); 
             }
             else {
                //1st curve point to ith curve point
                 LatLon tempPoint = getStreetSegmentCurvePoint (street_segment_id,i-1); //position of (i-1)th curve point
                 distance = distance + find_distance_between_two_points(tempPoint, curvePoint);
             }      
        }
         //ith curve point to the end point
         LatLon curvePoint = getStreetSegmentCurvePoint (street_segment_id,totalCount-1);
         distance = distance + find_distance_between_two_points(curvePoint,point2);
   }
    return distance;
    
 
}

//Returns the length of the specified street in meters
double find_street_length(unsigned street_id){
    
    std::vector<unsigned> allSeg = find_street_street_segments(street_id); // a vector contains all street segments of the given street
    
    double length =0 ;
    
    for (std::vector<unsigned>::iterator it = allSeg.begin(); it != allSeg.end(); ++it){
        //iterator through the whole list , get length of different segments, then add them up
        length = length + find_street_segment_length(*it);
    }
    return length;
    
    
}

//Returns the travel time to drive a street segment in seconds 
//(time = distance/speed_limit)
double find_street_segment_travel_time(unsigned street_segment_id){

}

//Returns the nearest point of interest to the given position
unsigned find_closest_point_of_interest(LatLon my_position){
    
}

//Returns the the nearest intersection to the given position
unsigned find_closest_intersection(LatLon my_position){
    
}